muscleName = ''
attachment_centroids = [0, 0]
attachment_normals = [0, 0]
csvDir = ''

allMuscleParameters = dict()

#   allMuscleParameters format:
#   {'muscleName' : [origArea, insertionArea, originCentroid, insertionCentroid, linearLength, muscleLength, muscleVolume]}
